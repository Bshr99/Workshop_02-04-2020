<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="description" content="Positionering">
	<link rel="stylesheet" type="text/css" href="css/style1.css">
	<title>Home</title>
</head>
<body>	
	<?php include ("inc/navigatie.php");?>
    
    <div class="cantainer">
		<div id="h1">
		<br>
		<h1>Welcome to GameWorld.</h1>
		<div class="text-two"><p>The most complete wbshop!</p></div>
		<HR WIDTH="40%" ALIGN="left" color="green">
		</div>
	</div>
	<div>
		<div class="blue-box">
	 	<a href="http://localhost/gameworld/games.php?gamecategoryid=1">Playstation</a>
		</div>
		<div class="black-box">
		<a href="http://localhost/gameworld/games.php?gamecategoryid=3">PC</a>	
		</div>
		<div class="green-box">
		<a href="http://localhost/gameworld/games.php?gamecategoryid=2">Xbox</a>
		</div>
		
		</div>
		<div class="footer">2019</div>
</body>
</html>