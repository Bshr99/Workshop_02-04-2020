<div class="logo"><a href="index.php"><h2>GameWorld</h2></div>
<nav id="main-navigation">
    <ul>
        <li><strong><a href="index.php">Home</strong></a></li>
        <li><strong><a href="about-us.php">About us</strong></a></li>
        <li><strong><a href="contact.php">Contact</strong></a></li>
        <li><strong><a href="checkout.php">CheckOut</strong></a></li>
    </ul>
</nav>