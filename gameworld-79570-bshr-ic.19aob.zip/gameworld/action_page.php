<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="description" content="Positionering">
	<link rel="stylesheet" type="text/css" href="css/style1.css">
	<title>Home</title>
</head>
<body>	
	<?php include ("inc/navigatie.php");?>

    <div id="bannerThanks">
        <h1 id="thanks"> Heel erg bedankt</h1>
        <p class="wij">Wij nemen zo snel mogelijk contact met u op!</p>	
    </div>
</body>